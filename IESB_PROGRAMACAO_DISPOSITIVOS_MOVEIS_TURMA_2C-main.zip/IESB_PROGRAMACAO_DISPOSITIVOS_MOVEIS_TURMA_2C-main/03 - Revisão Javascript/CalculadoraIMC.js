// Exportando uma função para ser usado em outro arquivo

export function calcularIMC(peso, altura) {
  return peso / (altura * altura)
}