// imports
import React from "react";
import {Text, View} from 'react-native'

// função do componente
export default function PrimeiroComponente() {

  // retorno com o JSX
  return (
    <View>
      <Text>
        Meu primeiro componente
      </Text>
    </View>
  );
  
}